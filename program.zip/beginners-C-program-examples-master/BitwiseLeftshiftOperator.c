// Bitwise left shift operator

#include <stdio.h>
int main()
{
    int a=7, b=2,c;
    c = a<<b;
    printf("Value of c = %d\n",c);
    return 0;

}
