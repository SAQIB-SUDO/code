#include<stdio.h>
void main()
{ float a,r;
printf("Enter the Radius : ");
scanf("%f",&s);
a=s*s;
printf("Area is %f",a);
}
