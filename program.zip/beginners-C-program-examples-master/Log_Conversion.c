#include <stdio.h>
#include <math.h>

int main(int argc, const char * argv[], value)
{
    /* Define temporary variables */
    double value;
    double result;

    /* Calculate the log of the value */
    result = log(value);

    /* Display the result of the calculation */
    printf("The Natural Logarithm of %f is %f\n", value, result);

    return 0;
}