#include<stdio.h>
void main()
{ float a,r;
printf("Enter the Radius : ");
scanf("%f",&r);
a=3.14*r*r;
printf("Area is %f",a);
}
